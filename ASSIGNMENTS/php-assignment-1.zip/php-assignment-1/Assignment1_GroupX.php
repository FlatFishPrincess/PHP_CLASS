<?php


/* ------------ submit comment ------------ 
    Fernando Chavez Riquelme - 300293540
    Jiweon Park - 300281074

*/
//Display warnings and notices
ini_set('display_errors',1);
error_reporting(E_ALL);

//Require utility classes and config
require_once("inc/config.inc.php");
require_once("inc/Validation.class.php");
require_once("inc/FileAgent.class.php");
require_once("inc/Page.class.php");
require_once("inc/Person.class.php");
require_once("inc/Book.class.php");

Page::header("Assignment #1 - Group X");

// read file
$fileContents = FileAgent::read(BOOK_FILE);

// parse filecontents and store people into book class
Book::parseBookData($fileContents);

// index for people array index in BOOK class
$index = 0;
$numberOfPeople = Book::getCount();

// if user click button, then check which button is clicked
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $index = $_POST["index"];

    if (isset($_POST['next'])) {  // next button clicked
        $index = ($index+1)%$numberOfPeople;
    } else if (isset($_POST['previous'])) { // previous button clicked
        ($index == 0) ? $index = $numberOfPeople - 1 : $index--;   // if index is current zero, go to last index, otherwise decrease by 1
    } else if(isset($_POST['submit'])){ // submit button clicked
        Validation::validateForm();  // validate form 
        if (!empty(Validation::$errors))
            Page::show_errors(Validation::$errors);
        else {  // if no errors, save form data
            $updateIndex = Book::getPersonByEmail($_POST["email"]);  // get person by email
            if($updateIndex == -1) // if index not found
                $updateIndex = $numberOfPeople;
            // update people array 
           Book::updatePerson($updateIndex, $_POST);
        }
    } else if(isset($_POST['delete'])){ // delete button clicked
        Book::deletePerson($index);
    }
} 

// write data in file
FileAgent::write(BOOK_FILE, Book::peopleToString());
// $fileContents = FileAgent::read(BOOK_FILE);
$person = Book::getPerson($index);
Page::displayForm($person, $index);

Page::footer();


?>
