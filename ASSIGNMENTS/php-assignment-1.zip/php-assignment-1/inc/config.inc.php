<?php

define("BOOK_FILE", "data/book.csv");

?>
