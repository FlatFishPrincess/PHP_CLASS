<?php

// book class is static, so need to add static keyword to each function?
class Book {

    public static $people = array();

     static function addPerson($person){
        self::$people[] = $person;
    }

    static function updatePerson($index, $formData){
        $personToUpdate = new Person(
                $formData["email"],
                $formData["firstName"],
                $formData["lastName"],
                $formData["gender"],
                $formData["address"],
                $formData["city"],
                $formData["country"]);
        self::$people[$index] = $personToUpdate;
    }

    // get people 
    static function getPeople(){
        return self::$people;
    }

    // get person with index
    static function getPerson($index){
        return self::$people[$index];
    }

    static function getCount(){
        return count(self::$people);
    }

    static function deletePerson($index){
        array_splice(self::$people, $index, 1);
    }
    

    public static function parseBookData($fileContents) {
        //Lines
        $lines = explode("\n", $fileContents);

        //Walk the lines
        for($i = 1;$i < count($lines); $i++) {
            //Pull the columns
            $columns = explode(",", $lines[$i]);
            try {
                if(empty($columns) || count($columns) != 7) {
                    throw new Exception("Problem parsing file at line: ".($i+1)."<br>");
                    continue;
                }
                //Add the person
                self::$people[] = new Person(
                    $columns[0],
                    $columns[1],
                    $columns[2],
                    $columns[3],
                    $columns[4],
                    $columns[5],
                    $columns[6]
                );
            } catch (Exception $ex) {
                Validation::$errors [] = $fe->getMessage();
            }
        }
        // if there's no person in people array, then add default data
        if (count(self::$people) == 0)
            self::$people[] = new Person("","","","Male","","","");
    }

    // @params email address
    // returns index of people array that has the same email as @email
    public static function getPersonByEmail($email) {
        $index = -1;
        $found = false;
        for ($i = 0; $i < count(self::$people) && !$found; $i++) {
            if (self::$people[$i]->email == $email) {
                $index = $i;
                $found = true;
            }
        }
        return $index;
    }

    public static function peopleToString() {
        $string = "email,firstname,lastname,gender,address,city,country\n";
        foreach (self::$people as $person) {
            $string .= $person->__toString();
        }
        $string = substr($string, 0, strlen($string)-1);
        return $string;
    }
}


?>
