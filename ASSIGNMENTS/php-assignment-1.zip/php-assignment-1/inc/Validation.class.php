<?php

class Validation {
    public static $errors = array();


    // validate form, make sure fileds should not be empty 
    static function validateForm(){
        if(strlen($_POST["email"]) == 0 || !strpos($_POST["email"], '@')){
            self::$errors[] = "Please put valid email";
        }
        if(strlen($_POST["firstName"]) == 0){
            self::$errors[] = "First Name is required";
        }
        if(strlen($_POST["lastName"]) == 0){
            self::$errors[] = "Last Name is required";
        }
        if(strlen($_POST["address"]) == 0){
            self::$errors[] = "address is required";
        }
        if(strlen($_POST["country"]) == 0){
            self::$errors[] = "country is required";
        }
        if(strlen($_POST["city"]) == 0){
            self::$errors[] = "city is required";
        }
    }
}


?>
