<?php

class Page  {

    static function header($title) {?>
        <!doctype html>
        <html lang="en">
        <head>
            <!-- Required meta tags -->
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

            <!-- Bootstrap CSS -->
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
            <title><?php echo $title ?></title>
        </head>
        <body>
            <div class="container">
            <h1><?php echo $title ?></h1>
            <br/>
    <?php
    }

    static function footer() {?>
            </div>
            <!-- Optional JavaScript -->
            <!-- jQuery first, then Popper.js, then Bootstrap JS -->
            <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
        </body>
        </html>
    <?php
    }
 // idisplay(ndex)  
    static function displayForm($person, $index) { ?> 
        <form method = "POST" action=<?php echo $_SERVER["PHP_SELF"];?>>
            <div class="form-row" >
                <div class="form-group col-md-6">
                    <label for="email">Email address</label>
                    <input type="text" name="email" class="form-control" id="email" value="<?php echo $person->email ?>">
                </div>
            <div class="form-group col-md-6">
                    <label for="firstName">First Name</label>
                    <input type= "text" name ="firstName" class="form-control" id="firstName" value="<?php echo $person->firstName ?>">
                </div>
            </div>
            <div class="form-row">
            <div class="form-group col-md-6">
                    <label for="lastName">Last Name</label>
                    <input type= "text"  name = "lastName"  class="form-control" id="lastName" value="<?php echo $person->lastName ?>">
                </div>
            <div class="form-group col-md-6">
                    <label for="gender">Gender</label>
                    <select class="form-control" id="gender" name = "gender">
                        <option value="Male" <?php if($person->gender == "Male") echo 'selected="selected"'; ?>>Male</option>
                        <option value="Female" <?php if($person->gender == "Female") echo 'selected="selected"'; ?>>Female</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="address">Street Address</label>
                <input type= "text"  name = "address" class="form-control" id="address" value="<?php echo $person->address ?>">
            </div>
            <div class="form-row">
            <div class="form-group col-md-6"> 
                    <label for="city">City</label>
                    <input type= "text"  name="city" class="form-control" id="city" value="<?php echo $person->city ?>">
                </div> 
            <div class="form-group col-md-6">
                    <label for="country">Country</label> 
                    <input type= "text"  name = "country" class="form-control" id="country" value="<?php echo $person->country ?>">
                </div> 
            </div>
            <div>
                <input type="hidden" name="index" value="<?php echo $index ?>">
            </div>
            <input type="submit" class="btn btn-outline-secondary" value="Previous" name="previous">
            <input type="submit" class="btn btn-primary" value="Submit" name="submit">
            <input type="submit" class="btn btn-danger" value="Delete" name="delete">
            <input type="submit" class="btn btn-outline-secondary" value="Next" name="next">
            <!-- index -->
        </form>
    <?php 
    }

    static function show_errors($errors)   {
        echo '<div class="alert alert-warning" role="alert">';
        echo 'The following errors were found:';
        echo '<UL>';
        foreach($errors as $error) {
            echo "<LI>$error</LI>";
        }
        echo '</UL>';
        echo '</div>';
    }

}
?>
