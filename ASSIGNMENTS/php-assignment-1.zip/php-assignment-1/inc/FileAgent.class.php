<?php

class FileAgent {
    // public static $people = array();
    
    static function read($fileName) {
        $contents = '';
        try {
            $fh = fopen($fileName, 'r');
            $contents = fread($fh, filesize($fileName));
            fclose($fh);
            if (!$fh) 
                throw new Exception("File $fileName could not be found!");
        } catch (Exception $fe) {
            Validation::$errors [] = $fe->getMessage();
        }
        return $contents;
    }
    
    static function write($fileName, $contents) {
        try {
            $fh = fopen($fileName, 'w');
            fwrite($fh, $contents);
            fclose($fh);
            if (!$fh)
                throw new Exception("File $fileName could not be written!");
        } catch (Exception $fe) {
            Validation::$errors [] = $fe->getMessage();
        }
    }

}

?>
