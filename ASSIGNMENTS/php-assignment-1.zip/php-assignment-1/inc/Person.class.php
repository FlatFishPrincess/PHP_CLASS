<?php

class Person {
    
    public $email = "";
    public $firstName = "";
    public $lastName = "";
    public $gender = "";
    public $address = "";
    public $city = "";
    public $country = "";

    public function __construct($email, $firstName, $lastName, $gender, $address, $city, $country) {
        $this->email = $email;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->gender = $gender;
        $this->address = $address;
        $this->city = $city;
        $this->country = $country;
    }
 
    public function __toString() {
        return "{$this->email},{$this->firstName},{$this->lastName},{$this->gender},{$this->address},{$this->city},{$this->country}\n";
    }
}

?>
