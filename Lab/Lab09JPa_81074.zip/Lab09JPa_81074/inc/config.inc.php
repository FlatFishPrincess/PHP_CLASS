<?php

//Database Connection parameters

define('DB_NAME',"Lab09");
define('DB_HOST',"localhost");
define('DB_PASS',"");
define('DB_USER',"root");

?>